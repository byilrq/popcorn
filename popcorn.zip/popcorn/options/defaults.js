window.AUTO_FEED_DEFAULTS = {
  "default_site_info": {
    "Audiences": {
        "url": "https://audiences.me/",
        "enable": 0
    },
    "BHD": {
        "url": "https://beyond-hd.me/",
        "enable": 0
    },
    "BTN": {
        "url": "https://broadcasthe.net/",
        "enable": 0
    },
    "CHDBits": {
        "url": "https://ptchdbits.co/",
        "enable": 0
    },
    "GPW": {
        "url": "https://greatposterwall.com/",
        "enable": 0
    },
    "MTeam": {
        "url": "https://kp.m-team.cc/",
        "enable": 0
    },
    "OPS": {
        "url": "https://orpheus.network/",
        "enable": 0
    },
    "OurBits": {
        "url": "https://ourbits.club/",
        "enable": 0
    },
    "PTP": {
        "url": "https://passthepopcorn.me/",
        "enable": 0
    },
    "RED": {
        "url": "https://redacted.sh/",
        "enable": 0
    },
    "TTG": {
        "url": "https://totheglory.im/",
        "enable": 0
    }
},
  "default_show_search_urls": {
      "PTP": 1,
      "BHD": 1,
      "CHD": 1,
      "ADE": 1,
      "GPW": 1,
      "BTN": 1,
      "豆瓣": 1
  },
  "default_extra_settings": {
    "ptp_show_douban": {
      "title": "PTP中文",
      "enable": 1
    },
    "ptp_show_group_name": {
      "title": "PTP组名",
      "enable": 1
    },
    "btn_dark_color": {
      "title": "妞暗色系",
      "enable": 1
    },
    "other_douban_info": {
      "title": "中文信息",
      "enable": 1
    }
  },
  "default_search_list": [
      "<a href=\"https://passthepopcorn.me/torrents.php?searchstr={imdbid}\" target=\"_blank\">PTP</a>",
      "<a href=\"https://beyond-hd.me/torrents?search={imdbid}\" target=\"_blank\">BHD</a>",
      "<a href=\"https://ptchdbits.co/torrents.php?incldead=0&spstate=0&inclbookmarked=0&search={imdbid}&search_area=4&search_mode=0\" target=\"_blank\">CHD</a>",
      "<a href=\"https://audiences.me/torrents.php?cat401=1&cat402=1&cat403=1&incldead=0&spstate=0&inclbookmarked=0&search={imdbid}&search_area=4\" target=\"_blank\">ADE</a>",
      "<a href=\"https://greatposterwall.com/torrents.php?searchstr={imdbid}\" target=\"_blank\">GPW</a>",
      "<a href=\"https://broadcasthe.net/torrents.php?action=advanced&searchstr=&searchtags=&tags_type=1&groupdesc=&imdbid={imdbid}\" target=\"_blank\">BTN</a>",
      "<a href=\"https://search.douban.com/movie/subject_search?search_text={imdbid}&cat=1002\" target=\"_blank\">豆瓣</a>"
  ],
  "default_common_sites": [
      "PTP",
      "BHD",
      "CHD",
      "ADE",
      "GPW",
      "BTN",
      "豆瓣"
  ],
  "default_rehost_img_info": {
    "freeimage": {
      "url": "https://freeimage.host/page/api",
      "api-url": "https://freeimage.host/api/1/upload",
      "api-key": ""
    },
    "imgbb": {
      "url": "https://api.imgbb.com/",
      "api-url": "https://api.imgbb.com/1/upload",
      "api-key": ""
    }
  }
};
